https://www.dropbox.com/s/rsy5x8f1yhlam6v/HTB-XEN.pdf?dl=0
passwd: d3r1v471v3_d0m41n_4dm1n

Breach XEN{wh0_n33d5_2f@?}
Deploy XEN{7ru573d_1n574ll3r5}
Ghost XEN{l364cy_5pn5_ftw}
Camouflage XEN{bu7_ld4p5_15_4_h455l3}
Doppelgänger XEN{y_5h4r3d_p@55w0Rd5?}
Owned XEN{d3r1v471v3_d0m41n_4dm1n}
